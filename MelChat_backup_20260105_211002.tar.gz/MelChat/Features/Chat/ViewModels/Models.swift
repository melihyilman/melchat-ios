import Foundation
import SwiftData

// MARK: - SwiftData Models

/// User model - represents a user in the app
@Model
final class User {
    @Attribute(.unique) var id: UUID
    var username: String
    var displayName: String?
    var email: String?
    var createdAt: Date
    var lastSeen: Date?
    var isOnline: Bool
    
    // Relationships
    @Relationship(deleteRule: .cascade) var sentMessages: [Message]?
    @Relationship(deleteRule: .cascade) var chats: [Chat]?
    
    init(id: UUID, username: String, displayName: String? = nil, email: String? = nil) {
        self.id = id
        self.username = username
        self.displayName = displayName
        self.email = email
        self.createdAt = Date()
        self.isOnline = false
    }
}

/// Message model - represents a single message
@Model
final class Message {
    @Attribute(.unique) var id: UUID
    var content: String
    var senderId: UUID
    var recipientId: UUID
    var chatId: UUID
    var contentType: ContentType
    var status: MessageStatus
    var isFromCurrentUser: Bool
    var timestamp: Date
    var isRead: Bool
    var encryptedContent: String?
    
    init(
        id: UUID,
        content: String,
        senderId: UUID,
        recipientId: UUID,
        chatId: UUID,
        contentType: ContentType = .text,
        status: MessageStatus = .sent,
        isFromCurrentUser: Bool,
        timestamp: Date = Date()
    ) {
        self.id = id
        self.content = content
        self.senderId = senderId
        self.recipientId = recipientId
        self.chatId = chatId
        self.contentType = contentType
        self.status = status
        self.isFromCurrentUser = isFromCurrentUser
        self.timestamp = timestamp
        self.isRead = false
    }
}

/// Chat model - represents a conversation with another user
@Model
final class Chat {
    @Attribute(.unique) var id: UUID
    var otherUserId: UUID?
    var otherUserName: String?
    var otherUserDisplayName: String?
    var lastMessageText: String?
    var lastMessageAt: Date?
    var lastMessageStatus: String?
    var unreadCount: Int
    var lastMessageFromMe: Bool?
    var createdAt: Date
    
    // Relationship
    @Relationship(deleteRule: .cascade) var messages: [Message]?
    
    init(
        id: UUID,
        otherUserId: UUID,
        otherUserName: String,
        otherUserDisplayName: String? = nil
    ) {
        self.id = id
        self.otherUserId = otherUserId
        self.otherUserName = otherUserName
        self.otherUserDisplayName = otherUserDisplayName
        self.unreadCount = 0
        self.createdAt = Date()
    }
}

/// Group model - represents a group chat (for future use)
@Model
final class Group {
    @Attribute(.unique) var id: UUID
    var name: String
    var createdBy: UUID
    var createdAt: Date
    var memberIds: [UUID]
    var avatarURL: String?
    
    init(id: UUID, name: String, createdBy: UUID, memberIds: [UUID] = []) {
        self.id = id
        self.name = name
        self.createdBy = createdBy
        self.createdAt = Date()
        self.memberIds = memberIds
    }
}

// MARK: - Enums

enum ContentType: String, Codable {
    case text
    case image
    case video
    case audio
    case file
    case voiceNote
}

enum MessageStatus: String, Codable {
    case sending
    case sent
    case delivered
    case read
    case failed
}
