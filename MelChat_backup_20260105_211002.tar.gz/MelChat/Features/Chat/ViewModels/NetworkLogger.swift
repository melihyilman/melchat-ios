import Foundation

// MARK: - Network Logger

/// Simple network logging utility for debugging
class NetworkLogger {
    static let shared = NetworkLogger()
    
    private var isEnabled = true
    private var logs: [(date: Date, message: String, group: String)] = []
    
    private init() {}
    
    func log(_ message: String, group: String = "General") {
        guard isEnabled else { return }
        
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        let logMessage = "[\(timestamp)] [\(group)] \(message)"
        
        print(logMessage)
        
        // Store for debug view
        logs.append((Date(), message, group))
        
        // Keep only last 100 logs
        if logs.count > 100 {
            logs.removeFirst()
        }
    }
    
    func logRequest(_ request: URLRequest, body: (any Encodable)? = nil) {
        var message = "→ \(request.httpMethod ?? "?") \(request.url?.absoluteString ?? "?")"
        
        if let body = body {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            if let data = try? encoder.encode(body),
               let json = String(data: data, encoding: .utf8) {
                message += "\nBody: \(json)"
            }
        }
        
        log(message, group: "Network")
    }
    
    func logResponse(_ response: HTTPURLResponse, data: Data) {
        var message = "← \(response.statusCode) \(response.url?.absoluteString ?? "?")"
        
        if let json = try? JSONSerialization.jsonObject(with: data),
           let prettyData = try? JSONSerialization.data(withJSONObject: json, options: .prettyPrinted),
           let prettyString = String(data: prettyData, encoding: .utf8) {
            message += "\n\(prettyString)"
        } else if let string = String(data: data, encoding: .utf8) {
            message += "\n\(string)"
        }
        
        log(message, group: "Network")
    }
    
    func getAllLogs() -> [(date: Date, message: String, group: String)] {
        return logs
    }
    
    func clearLogs() {
        logs.removeAll()
    }
    
    func enable() {
        isEnabled = true
    }
    
    func disable() {
        isEnabled = false
    }
}
